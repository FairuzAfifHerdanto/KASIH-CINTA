<?php
error_reporting(E_ALL); // Menampilkan semua jenis error
ini_set('display_errors', 1); // Menampilkan error ke browser

require_once dirname(__FILE__) . '/vendor/midtrans/midtrans-php/Midtrans.php'; 
use Midtrans\Config;
use Midtrans\Snap;

// Konfigurasi Midtrans
Config::$serverKey = 'SB-Mid-server-82XUenr32NN4T6vloJa7AAn1';
Config::$isProduction = false; // Ganti ke true jika menggunakan mode production
Config::$isSanitized = true;
Config::$is3ds = true;

// Ambil data dari request
$data = json_decode(file_get_contents('php://input'), true);

// Periksa apakah data diterima dengan benar
if (!$data || !isset($data['donationAmount']) || !isset($data['donorName']) || !isset($data['donorEmail'])) {
    echo json_encode(['error' => 'Missing required data.']);
    exit;
}

// Parameter transaksi
$transaction_details = array(
    'order_id' => rand(), // ID unik transaksi
    'gross_amount' => $data['donationAmount'], // Nominal donasi
);

$customer_details = array(
    'first_name' => $data['donorName'],
    'last_name' => NULL,
    'email' => $data['donorEmail'],
    'phone' => $data['donorNo_Telepon'],
);

$params = array(
    'transaction_details' => $transaction_details,
    'customer_details' => $customer_details,
);

try {
    $snapToken = \Midtrans\Snap::getSnapToken($params);
    echo json_encode(['token' => $snapToken]);
} catch (Exception $e) {
    echo json_encode(['error' => 'Error generating Snap token: ' . $e->getMessage()]);
}
?>