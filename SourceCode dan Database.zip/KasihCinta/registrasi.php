<?php
session_start();
include("koneksi.php");
require 'vendor/autoload.php'; // PHPMailer autoload

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = htmlspecialchars(trim($_POST['full_name']));
    $alamat = htmlspecialchars(trim($_POST['address']));
    $username = htmlspecialchars(trim($_POST['username']));
    $telepon = htmlspecialchars(trim($_POST['phone']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Periksa apakah email atau username sudah ada
    $check_query = $con->prepare("SELECT * FROM donatur WHERE Username = ? OR Email = ?");
    $check_query->bind_param("ss", $username, $email);
    $check_query->execute();
    $result = $check_query->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username atau email sudah terdaftar! Gunakan username atau email yang berbeda.');</script>";
    } else {
        // Generate kode OTP
        $otp_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        // Prepare and bind
        $stmt = $con->prepare("INSERT INTO donatur (Nama, Alamat, Username, Email, No_Telepon, Password, otp_code, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
        $stmt->bind_param("sssssss", $nama, $alamat, $username, $email, $telepon, $hashedPassword, $otp_code);

        if ($stmt->execute()) {
            // Kirim email OTP
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Gunakan server SMTP sesuai provider
                $mail->SMTPAuth = true;
                $mail->Username = 'fairuzafifherdanto@gmail.com'; // Ganti dengan email Anda
                $mail->Password = 'kike zbrj ylhd odpm'; // Ganti dengan password email Anda
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Pengaturan email
                $mail->setFrom('your_email@gmail.com', 'Kasih Cinta');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Verifikasi Email Anda';
                $mail->Body = "Halo $nama,<br><br>Terima kasih telah mendaftar. Berikut adalah kode OTP Anda: <b>$otp_code</b><br>Masukkan kode ini untuk memverifikasi email Anda.";

                $mail->send();
                echo "<script>alert('Registrasi berhasil! Silakan cek email Anda untuk verifikasi.'); window.location.href='verifikasi.php?email=$email';</script>";
                exit();
            } catch (Exception $e) {
                echo "<script>alert('Gagal mengirim email: {$mail->ErrorInfo}');</script>";
            }
        } else {
            echo "<script>alert('Terjadi kesalahan saat registrasi. Silakan coba lagi.');</script>";
        }

        // Close the statement
        $stmt->close();
    }

    // Close the query and connection
    $check_query->close();
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Kasih Cinta</title>
    <link rel="stylesheet" href="assets/css/registrasi.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .password-container {
            position: relative;
        }

        .password-container i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <div class="register-card">
            <h1>Join Us</h1>
            <p>Create your account and start your journey</p>
            <form id="registration-form" method="POST">
                <div class="form-group">
                    <label for="full-name">Nama Lengkap</label>
                    <input type="text" id="full-name" name="full_name" placeholder="Masukkan nama lengkap Anda" required>
                </div>
                <div class="form-group">
                    <label for="address">Alamat</label>
                    <textarea id="address" name="address" placeholder="Masukkan alamat Anda" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Masukkan username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Masukkan email Anda" required>
                </div>
                <div class="form-group">
                    <label for="phone">No. Telepon</label>
                    <input type="tel" id="phone" name="phone" placeholder="Masukkan nomor telepon Anda" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" placeholder="Buat password" required>
                        <i class="fas fa-eye" id="toggle-password"></i>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password_confirm">Konfirmasi Password</label>
                    <div class="password-container">
                        <input type="password" id="password_confirm" name="password_confirm" placeholder="Konfirmasi password" required>
                        <i class="fas fa-eye" id="toggle-password-confirm"></i>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Sign Up</button>
                </div>
            </form>
            <div class="login-link">
                <p>Already have an account? <a href="login.php">Log in</a></p>
            </div>
        </div>
    </div>

    <script>
        // Toggle password visibility
        document.getElementById('toggle-password').addEventListener('click', function () {
            const passwordField = document.getElementById('password');
            const type = passwordField.type === 'password' ? 'text' : 'password';
            passwordField.type = type;
            this.classList.toggle('fa-eye-slash', type === 'text');
            this.classList.toggle('fa-eye', type === 'password');
        });

        document.getElementById('toggle-password-confirm').addEventListener('click', function () {
            const confirmPasswordField = document.getElementById('password_confirm');
            const type = confirmPasswordField.type === 'password' ? 'text' : 'password';
            confirmPasswordField.type = type;
            this.classList.toggle('fa-eye-slash', type === 'text');
            this.classList.toggle('fa-eye', type === 'password');
        });

        // Validasi form sebelum submit
        document.getElementById('registration-form').addEventListener('submit', function (event) {
            const password = document.getElementById('password').value;
            const passwordConfirm = document.getElementById('password_confirm').value;

            // Pola untuk validasi password
            const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            // Cek validasi password
            if (!password.match(passwordPattern)) {
                alert("Password harus memiliki minimal 8 karakter, mengandung huruf besar, angka, dan simbol.");
                event.preventDefault(); // Jangan submit form
                return;
            }

            // Cek kecocokan password dan konfirmasi password
            if (password !== passwordConfirm) {
                alert("Password dan konfirmasi password tidak cocok.");
                event.preventDefault(); // Jangan submit form
                return;
            }
        });
    </script>
</body>

</html>