<?php
session_start();
include("koneksi.php");
require 'vendor/autoload.php'; // Include PHPMailer Autoload

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format.";
    } else {
        // Cek email di database
        $query = "SELECT * FROM donatur WHERE Email = ?";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $token = bin2hex(random_bytes(50));
            $expires_at = date("Y-m-d H:i:s", strtotime('+1 hour'));

            // Simpan token di database
            $updateQuery = "UPDATE donatur SET reset_token = ?, reset_expires_at = ? WHERE Email = ?";
            $updateStmt = $con->prepare($updateQuery);
            $updateStmt->bind_param("sss", $token, $expires_at, $email);
            $updateStmt->execute();

            // Kirim Email Menggunakan PHPMailer
            $resetLink = "localhost/kasihcinta/reset_password.php?token=$token";

            try {
                $mail = new PHPMailer(true);

                // Konfigurasi Server SMTP
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Server SMTP, ganti jika pakai selain Gmail
                $mail->SMTPAuth = true;
                $mail->Username = 'fairuzafifherdanto@gmail.com'; // Email Anda
                $mail->Password = 'kike zbrj ylhd odpm'; // Password email Anda
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                // Pengirim dan Penerima
                $mail->setFrom('your-email@gmail.com', 'Kasih Cinta');
                $mail->addAddress($email);

                // Konten Email
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body = "
                    <h3>Password Reset Request</h3>
                    <p>Click the link below to reset your password:</p>
                    <a href='$resetLink'>$resetLink</a>
                    <p>This link will expire in 1 hour.</p>
                ";

                $mail->send();
                $message = "A reset password link has been sent to your email.";
            } catch (Exception $e) {
                $message = "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $message = "Email not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="assets/css/forgot_password.css">
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Send Reset Link</button>
        </form>
        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>