<?php
session_start();
include("koneksi.php");

$message = "";
$success = false; // Flag untuk status sukses
$invalidToken = false; // Flag untuk token invalid atau kedaluwarsa

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Cek token valid
    $query = "SELECT id_donatur, reset_expires_at FROM donatur WHERE reset_token = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id_donatur = $row['id_donatur'];
        $expires_at = strtotime($row['reset_expires_at']);

        if (time() < $expires_at) {
            // Token valid, proses reset password
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
                $updateQuery = "UPDATE donatur SET Password = ?, reset_token = NULL, reset_expires_at = NULL WHERE id_donatur = ?";
                $updateStmt = $con->prepare($updateQuery);
                $updateStmt->bind_param("si", $new_password, $id_donatur);
                $updateStmt->execute();

                $message = "Your password has been successfully reset.";
                $success = true; // Tandai sebagai sukses
            }
        } else {
            $message = "The reset link has expired.";
            $invalidToken = true; // Tandai token tidak valid
        }
    } else {
        $message = "Invalid or expired token.";
        $invalidToken = true; // Tandai token tidak valid
    }
} else {
    header("Location: forgot_password.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="assets/css/reset_password.css">
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <?php if ($message): ?>
            <div class="message"> <?php echo htmlspecialchars($message); ?> </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <!-- Jika berhasil reset password -->
            <a href="login.php">
                <button type="button">Go to Login</button>
            </a>
        <?php elseif ($invalidToken): ?>
            <!-- Jika token tidak valid atau kedaluwarsa -->
            <a href="forgot_password.php">
                <button type="button">Back to Forgot Password</button>
            </a>
        <?php else: ?>
            <!-- Form reset password hanya muncul jika token valid -->
            <form method="POST" action="">
                <input type="password" name="new_password" placeholder="Enter new password" required>
                <button type="submit">Reset Password</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
