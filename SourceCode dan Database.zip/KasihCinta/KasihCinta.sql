-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: btd2ishhks9bqlvbicyt-mysql.services.clever-cloud.com:3306
-- Generation Time: Dec 24, 2024 at 02:59 AM
-- Server version: 8.0.22-13
-- PHP Version: 8.2.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `btd2ishhks9bqlvbicyt`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id_Admin` int NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Foto` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `donatur`
--

CREATE TABLE `donatur` (
  `Id_Donatur` int NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Alamat` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `No_Telepon` varchar(15) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `otp_code` int DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT NULL COMMENT 'true or false',
  `reset_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `donatur`
--

INSERT INTO `donatur` (`Id_Donatur`, `Nama`, `Alamat`, `Username`, `Email`, `No_Telepon`, `Password`, `otp_code`, `is_verified`, `reset_token`) VALUES
(85, 'Septiyadi', 'Purwokerto', 'septiyadi', 'septiyadisusanto70@gmail.com', '098721453893', '$2y$10$BfGKnKPskPl5PiTZuA.ehesEuPDhusRdLixH.CEOCUHC5wpqk0KP.', 849201, 1, NULL),
(86, 'cindy', 'wisma rahayu', 'cindy', '2211102127@ittelkom-pwt.ac.id', '087884729472', '$2y$10$c5PrHGEjAhJSnCA0cJVEceM/jy0RL.yI2pTpwDPFylmiwfdJvdFlq', 23421, 1, NULL),
(87, 'Rifatul Hidayah', 'cirebon', 'Rifa', 'hidayahrieva@gmail.com', '082219800195', '$2y$10$5IlmsPEhzWpBBoX3aL7zHuKVTrKFldosdfClIHJO2EAbyhjs2p6bu', 701385, 1, NULL),
(88, 'else mira fania', 'PALEMBANG', 'else mirfania', 'elsemirafania@gmail.com', '088286147063', '$2y$10$Ye9j.fqb9VmzhF4LKEAp7.22BruGfYpinqzV2rhsVAGjrjTCYuIe6', 648115, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `donee`
--

CREATE TABLE `donee` (
  `id_donee` int NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nama_bank` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `deskripsi` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `contactdetail` decimal(10,0) NOT NULL,
  `nomor_bank` int NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `donee`
--

INSERT INTO `donee` (`id_donee`, `nama`, `nama_bank`, `deskripsi`, `contactdetail`, `nomor_bank`, `foto`) VALUES
(20, 'Kirana Lestari', 'BCA', 'Kirana berjalan sendirian di trotoar yang sepi, wajahnya muram dan mata yang kosong. Tak ada tempat yang bisa disebut rumah, hanya jalanan yang dingin dan malam yang sunyi. Mencari sisa-sisa makanan dari orang yang tak pernah melihatnya. Di dunia yang terus bergerak, Kirana hanya bisa berharap ada yang peduli, mari kita peduli #bantukirana', 8224454121, 12964130, 'kirana.jpg'),
(21, 'Pak Sanuri ', 'BRI', 'Sanuri duduk di sudut jalan, tubuhnya yang rapuh semakin lemah karena sakit yang terus menggerogoti. Wajahnya pucat, tubuhnya gemetar, dan setiap napas terasa berat. Dulu, ia pernah memiliki segalanya—keluarga, rumah, kebahagiaan. Namun kini, ia tak punya uang, tak ada yang bisa membantunya. Setiap hari ia hanya berharap ada sedikit bantuan, meski tahu orang-orang yang lewat tak akan melihatnya. Sakit yang ia rasakan semakin mempersakit hatinya, karena ia tahu bahwa tak ada yang datang untuk menolongnya, hanya sepi yang menemani.', 822441313, 311212, 'ahmad.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `Id_Transaksi` int NOT NULL,
  `Id_Donatur` int NOT NULL,
  `Id_Donee` int NOT NULL,
  `Tanggal` date NOT NULL,
  `Jumlah` int NOT NULL,
  `Bukti` blob NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id_Admin`);

--
-- Indexes for table `donatur`
--
ALTER TABLE `donatur`
  ADD PRIMARY KEY (`Id_Donatur`);

--
-- Indexes for table `donee`
--
ALTER TABLE `donee`
  ADD PRIMARY KEY (`id_donee`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`Id_Transaksi`),
  ADD UNIQUE KEY `Id_Donee` (`Id_Donee`),
  ADD KEY `transaksi_ibfk_1` (`Id_Donatur`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donatur`
--
ALTER TABLE `donatur`
  MODIFY `Id_Donatur` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `donee`
--
ALTER TABLE `donee`
  MODIFY `id_donee` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`Id_Donatur`) REFERENCES `donatur` (`Id_Donatur`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`Id_Donee`) REFERENCES `donee` (`id_donee`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
