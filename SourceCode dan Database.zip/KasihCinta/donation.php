<?php
// Koneksi ke database
session_start();
include("koneksi.php");
include("functions.php");
$user_data = check_login($con);

// Cek koneksi
if ($con->connect_error) {
    die("Koneksi gagal: " . $con->conect_error);
}

// Get the donation ID from the URL parameter
$donationId = $_GET['id_donee'];

// Query to fetch the specific donation
$sql = "SELECT * FROM donee WHERE Id_Donee = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $donationId);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Support those in need with your donation">
    <title>Donation Detail</title>
    <link rel="stylesheet" href="assets/css/donationx.css">
</head>

<body>
    <?php if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); ?>
        <!-- Header Section -->
        <header class="header">
            <div class="container">
                <a href="index.php" class="back-link">← Back</a>
                <h1>Donation Detail - <?php echo $row['nama']; ?> </h1>
            </div>
        </header>

        <!-- Main Content -->
        <main>




            <!-- Image Gallery -->
            <section class="image-gallery">
                <img src="assets/img/<?php echo $row['foto']; ?>" alt="<?php echo $row['nama']; ?>" class="card-image">
            </section>

            <!-- About Section -->
            <section class="about container">
                <h2>Tentang <?php echo $row['nama'] ?></h2>
                <p><?php echo $row['deskripsi']; ?></p>
            </section>

            <!-- Donation Details -->
            <section class="donation-details container">
                <h2>Info Donasi</h2>
                <div class="donation-card">
                    <h3>Bank: <?php echo $row['nama_bank']; ?></h3>
                    <p>Nomor Bank: <?php echo $row['nomor_bank']; ?></p>
                    <a href="payment.php"><button class="donate-btn" onclick="window.location.href = 'payment.php"> Donasi Sekarang </button></a>
                </div>
            </section>

            <!-- Contact Details -->
            <section class="contact container">
                <h2>Biodata <?php echo $row['nama'] ?></h2>
                <p>Nama: <?php echo $row['nama']; ?></p>
                <p>Contact: <?php echo $row['contactdetail']; ?></p>
    
            </section>

        <?php } else { ?>
            <p class="error-message">Donation not found.</p>
        <?php } ?>
        </main>

        <!-- Footer Section -->
        <footer class="footer">
            <div class="container">
                <p>&copy; 2024 Donation Platform. Together, we make a difference.</p>
            </div>
        </footer>
</body>

</html>