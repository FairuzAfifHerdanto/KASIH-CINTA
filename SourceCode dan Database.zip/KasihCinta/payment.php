<?php
session_start();
include("koneksi.php");

// Pastikan pengguna login
if (!isset($_SESSION['id_donatur'])) {
    header("Location: login.php");
    exit();
}

// Ambil data donatur dari session
$id_donatur = $_SESSION['id_donatur'];
$query = "SELECT Nama, Email, No_Telepon FROM donatur WHERE id_donatur = ?";
$stmt = $con->prepare($query);
$stmt->bind_param("i", $id_donatur);
$stmt->execute();
$stmt->bind_result($donorName, $donorEmail, $donorNo_Telepon);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <script type="text/javascript"
      src="https://app.sandbox.midtrans.com/snap/snap.js"
      data-client-key="SB-Mid-client-zPROVJguo_LZs87i"></script>
    <link rel="stylesheet" href="assets/css/payment.css">
</head>
<body>
    <h1>Payment for Donation</h1>
    <p>Thank you, <strong><?php echo htmlspecialchars($donorName); ?></strong> for your support!</p>
    <p>Email: <?php echo htmlspecialchars($donorEmail); ?></p>
    
    <!-- Form untuk input nominal donasi -->
    <form id="donation-form">
        <label for="donation-amount">Enter Donation Amount (IDR):</label>
        <input type="number" id="donation-amount" name="donation_amount" min="10000" required>
        <button type="submit">Proceed to Payment</button>
    </form>

    <script>
        document.getElementById('donation-form').addEventListener('submit', function (e) {
            e.preventDefault(); // Mencegah form di-submit secara default

            const donationAmount = document.getElementById('donation-amount').value;

            // Validasi nominal donasi
            if (donationAmount < 10000) {
                alert('Minimum donation amount is IDR 10,000.');
                return;
            }

            // Kirim data ke server untuk mendapatkan token transaksi
            fetch('get_transaction_token.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    donationAmount: donationAmount,
                    donorName: "<?php echo addslashes($donorName); ?>",
                    donorEmail: "<?php echo addslashes($donorEmail); ?>",
                    donorNo_Telepon: "<?php echo addslashes($donorNo_Telepon); ?>"
                })
            })
            .then(response => response.text())
            .then(text => {
                try {
                    const data = JSON.parse(text);
                    if (data.token) {
                        window.snap.pay(data.token, {
                            // Callback on success
                            onSuccess: function(result) {
                                alert('Payment successful! Thank you for your donation.');
                                window.location.href = 'index.php';
                            },
                            // Callback on pending
                            onPending: function(result) {
                                alert('Payment pending. Please complete the payment process.');
                                window.location.href = 'index.php';
                            },
                            // Callback on error
                            onError: function(result) {
                                alert('Payment failed. Please try again.');
                                console.error(result);
                            },
                            // Callback on close
                            onClose: function() {
                                alert('Payment popup closed. Please try again if you want to donate.');
                            }
                        });
                    } else {
                        alert('Error generating payment token. Please try again.');
                    }
                } catch (error) {
                    console.error('JSON parsing error:', error);
                }
            })
            .catch(error => console.error('Error:', error));
        });
    </script>
</body>
</html>
