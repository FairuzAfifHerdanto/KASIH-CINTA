<?php
$msg = "";
if (isset($_POST['submit'])) {
    // Database connection
    $db = mysqli_connect("btd2ishhks9bqlvbicyt-mysql.services.clever-cloud.com", "uzx5rpy9fd8ngm0d", "FXd0uin6iaOl6WgAehaq", "btd2ishhks9bqlvbicyt");
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get form data
    $nama = $_POST['nama'];
    $nama_bank = $_POST['nama_bank'];
    $deskripsi = $_POST['deskripsi'];
    $contactdetail = $_POST['contactdetail'];
    $nomor_bank = $_POST['nomor_bank'];
    $foto = $_FILES['foto']['name'];
    $target = "assets/img/" . basename($_FILES['foto']['name']);

    // Insert data into the "donee" table
    $sql = "INSERT INTO donee (nama, nama_bank, deskripsi, contactdetail , nomor_bank , foto) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($db, $sql);
    mysqli_stmt_bind_param($stmt, "ssssss", $nama, $nama_bank, $deskripsi, $contactdetail, $nomor_bank, $foto);

    if (mysqli_stmt_execute($stmt)) {
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
            // Jika berhasil, tampilkan pesan sukses
            echo "Data berhasil ditambahkan!";
        }
    } else {
        // Jika gagal, tampilkan pesan kesalahan yang lebih spesifik
        echo "Terjadi kesalahan: " . mysqli_error($db);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($db);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard - Donasi</title>
    <link rel="stylesheet" href="assets/css/beranda-admin.css" />
</head>

<body>
    <div class="admin-container">
        <header>
            <h1>Admin Dashboard - Donasi</h1>
        </header>

        <main>
            <!-- Form untuk Tambah Donasi -->
            <section class="form-section">
                <h2>Tambah Donasi</h2>
                <form action="" method="POST" enctype="multipart/form-data">
                    <label for="donasiName">Nama:</label>
                    <input type="text" id="nama" name="nama" placeholder="Masukkan nama" required />

                    <label for="nama_bank">nama_bank:</label>
                    <input type="text" id="nama_bank" name="nama_bank" placeholder="Masukkan alamat" required />

                    <label for="nomor_bank">Nomor Rekening:</label>
                    <input type="number" id="nomor_bank" name="nomor_bank" placeholder="Masukkan jumlah donasi" required />

                    <label for="contactdetail">Kontak Korban:</label>
                    <input type="number" id="contactdetail" name="contactdetail" placeholder="contactdetail" required></textarea>

                    <label for="description">Deskripsi:</label>
                    <textarea id="deskripsi" name="deskripsi" placeholder="Masukkan deskripsi" required></textarea>

                    <label for="foto">Foto:</label>
                    <input type="file" id="foto" name="foto" required />

                    <button type="submit" name="submit">Tambah Donasi</button>
                </form>
            </section>

            <!-- Tabel Data Donasi -->
            <section class="data-section">
                <h2>Data Donasi</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Deskripsi</th>
                            <th>Jumlah</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="donasiTable">
                        <!-- Data donasi akan dimasukkan di sini melalui JavaScript -->
                    </tbody>
                </table>
            </section>
            <p><?php echo $msg; ?></p>
        </main>
    </div>


</body>

</html>